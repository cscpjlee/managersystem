#pragma once
#include<stdio.h>
#include<string.h>
#include"model.h"s
void add();
int getSize(const char* pInfo);
void query();
void copy(char* aInput, char* aOutput, int nSize);