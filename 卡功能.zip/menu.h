#pragma once
#include<stdio.h>
#include<string.h>
#include"model.h"
//void showMenu();//�˵�����
//void add_card(Card cards[], int* number);//����
//int  find_card(Card cards[], int number, char* s, char* p);//Ѱ��
//void delete_card(Card cards[], int* number, char* s, char* p);//ע��
//void check_card(Card cards[], int number, char* s, char* p);//��ѯ
//void on_board(Card cards[], char* s, char* password);//�ϻ�
//void off_board(Card cards[], char* s, char* password);//�»�
//void recharge_card(Card cards[], int* number, char* s, int m);//��ֵ
//void refund_card(Card cards[]);//�˷�
void add();
int getSize(const char* pInfo);
void query();