#pragma once
#include"model.h"
extern lpCardNode cardList;
void saveCardListToFile();
void loadCardListFromFile();
void resetSystemData();