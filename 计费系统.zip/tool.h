#pragma once
#include<time.h>
void timeToString(time_t t, char* pBuf);
